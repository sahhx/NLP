DeepLearningMovies
==================

Kaggle's competition for using Google's word2vec package for sentiment analysis

## Installation

There're some requirements for making the stuff work. Use `pip` to install them easily:

```bash
$> sudo pip install -r requirements.txt
```